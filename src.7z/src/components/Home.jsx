import minhafoto from "../assets/FotoPessoal.jpg";

const Home = () => {
  return (
    <div className="home">
      <img className="img" src={minhafoto} alt="" />
      <h1>Bem-vindo ao meu portfólio!</h1>
      <div className="while">
        <p>
        Olá, meu nome é Italo Nathanael, tenho 22 anos e estou cursando Análise e Desenvolvimento de Software, área que escolhi por seu dinamismo e relevância no mercado atual. Atualmente, atuo na área administrativa, onde utilizo minhas habilidades organizacionais e analíticas para lidar com diferentes demandas, fazendo uso frequente do Excel em um nível intermediário para gerenciar dados e otimizar processos. Estou sempre em busca de novas oportunidades para aplicar e expandir meus conhecimentos, unindo a tecnologia à prática profissional. <b>Navegue pelas abas para saber mais sobre mim.</b>
        </p>
      </div>
    </div>
  );
};

export default Home;
