
import Lista from "../assets/lista de tarefas.png";
import pokemon from "../assets/pokemon.png";

const Portfolio = () => {
  return (
    <div className="portfolio">
      <h1>Projetos</h1>

      <div className="Projeto_Pokemon">
        <img src={pokemon} alt="Projeto 1" />
        <div className="projeto_Lista">
          <h2>POKEDEX</h2>
          <p>
            Aplicação que mostra todos os pokemons. Nesse
            site, podendo pesquisa-los através de seu nome ou id.
          </p>
          <a
            href="https://github.com/italonathanael/pokedex.git"
            target="_blank"
            rel="noopener noreferrer"
          >
            Ver no GitHub
          </a>
        </div>
      </div>


      <div className="Projeto_Pokemon">
        <img src={Lista} alt="Projeto 2" />
        <div className="projeto_Lista">
          <h2>LISTA DE TAREFAS</h2>
          <p>Aplicação aplicação de lista de tarefas para o dia a dia.</p>
          <a
            href="https://github.com/italonathanael/lista-de-tarefas.git"
            target="_blank"
            rel="noopener noreferrer"
          >
            Ver no GitHub
          </a>
        </div>
      </div>
    </div>
  );
};

export default Portfolio;
