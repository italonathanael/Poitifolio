import { useState } from "react";

const Contato = () => {

  const [submitted, setSubmitted] = useState(false);


  const handleSubmit = (e) => {
    e.preventDefault(); 
    setSubmitted(true); 
  };

  return (
    <div className="tela">
    <div className="informacao">
      <h1>Entre em Contato</h1>
      <div className="contato">
        <strong>Nome:</strong>
        <p>Italo Nathanael</p>
      </div>
      <div className="contato">
        <strong>Contato:</strong>
        <p>(84) 9 91016954</p>
      </div>
      <div className="contato">
        <strong>GitHub:</strong>
        <p>
          <a
            href="https://github.com/italonathanael"
            target="_blank"
            rel="noopener noreferrer"
          >
            github.com/italonathanael
          </a>
        </p>
      </div>
      <div className="contato">
        <strong>E-mail:</strong>
        <p>
          <a href="italonathanael4@gmail.com">italonathanael4@gmail.com</a>
        </p>
      </div>

 
      <form onSubmit={handleSubmit}>
        <div className="formes">
          <label htmlFor="name">Nome:</label>
          <input
            type="text"
            id="name"
            name="name"
            placeholder="Digite seu nome"
            required
          />
        </div>
        <div className="formes">
          <label htmlFor="email">E-mail:</label>
          <input
            type="email"
            id="email"
            name="email"
            placeholder="Digite seu e-mail"
            required
          />
        </div>
        <div className="formes">
          <label htmlFor="message">Mensagem:</label>
          <textarea
            id="message"
            name="message"
            rows="4"
            placeholder="Digite sua mensagem"
            required
          ></textarea>
        </div>
        <button className="botao" type="submit">Enviar Mensagem</button>
      </form>


      {submitted && (
        <div className="mensagem">
          <p>Sua mensagem foi enviada com sucesso.</p>
        </div>
      )}
    </div>
    </div>
  );
};

export default Contato;
