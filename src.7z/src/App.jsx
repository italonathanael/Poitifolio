import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./components/Home";
import Portfolio from "./components/Portfolio";
import Contato from "./components/Contato";
import "./index.css"; 
import "./app.css"; 

const App = () => ( 
  <Router>
    <header>
      <nav >
        <ul>
          <li >
            <a href="/">Home</a>
          </li>
          <li className="cachorro">
            <a href="/portfolio">Portfólio</a>
          </li>
          <li className="cachorro">
            <a href="/contato">Contato</a>
          </li>
        </ul>
      </nav>
    </header>
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/portfolio" element={<Portfolio />} />
      <Route path="/contato" element={<Contato />} />
      <Route path="*" element={<h2>Página não encontrada</h2>} />
    </Routes>
  </Router>
);

export default App;
